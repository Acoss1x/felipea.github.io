-- =====================================================================
-- Bases de Datos 2 · Taller integrador — Banco Andino
-- 01_sesion_A.sql        >>>  CONEXIÓN A  <<<   (cajero A)
--
-- NO ejecute este archivo de corrido. Cada bloque dice PASO n:
-- ejecútelo con Ctrl+Enter cuando le toque, alternando con la conexión B.
--
-- ANTES DE EMPEZAR, verifique:
--   1. Autocommit APAGADO
--      Herramientas > Preferencias > Base de datos > Avanzado > Autoconfirmar
--      (debe estar DESMARCADO)
--   2. Dos CONEXIONES distintas, no dos hojas sobre la misma conexión.
-- =====================================================================

SELECT 'CONEXIÓN A' AS ventana, SYS_CONTEXT('USERENV','SID') AS sid FROM dual;


-- #####################################################################
-- EJERCICIO 1.1 — El retiro que se pierde (actualización perdida)
--
-- Escenario: el mismo cliente retira por el cajero automático mientras
-- su empresa le hace un débito automático. Las dos operaciones leen el
-- saldo, restan en memoria y escriben el resultado. Es lo que hace la
-- mayoría del código que ustedes van a encontrar en producción.
--
-- Cuenta 1001, saldo inicial 1.000.000.
-- #####################################################################

-- PASO 1  (A)  Estado inicial
SELECT id_cuenta, saldo, saldo_retenido, version
  FROM cuenta WHERE id_cuenta = 1001;
--> Anote el SALDO. Debe ser 1.000.000.

-- PASO 2  (A)  "El cajero" leyó 1.000.000 y calculó 1.000.000 - 300.000
UPDATE cuenta SET saldo = 700000 WHERE id_cuenta = 1001;
--  NO confirme todavía.

-- ... vaya a la conexión B, PASO 3 ...

-- PASO 5  (A)  Confirmo mi retiro de 300.000
COMMIT;

-- ... conexión B, PASO 6 ...

-- PASO 8  (A)  ¿Cuánto saldo quedó?
SELECT id_cuenta, saldo FROM cuenta WHERE id_cuenta = 1001;
--
--  PREGUNTA 1.1 — Salieron 300.000 (A) más 200.000 (B) = 500.000 de
--  1.000.000. Deberían quedar 500.000. ¿Cuántos quedan? ¿Quién "ganó"?
--  ¿Hubo algún error, alguna advertencia, algún registro de que algo
--  salió mal?

-- Fue asi: Yo hice un select y el saldo era 1.000.000
-- Luego quedaron 700,000 sin commit
-- Mi compañero hizo un select y aún ve 1.000.000
-- Intentó hacer un update a 800,000 pero se bloquea, esperando mi confirmación
-- Luego yo hago el commit y ya se libera el bloqueo para el.
-- Al final quedan 800,000 gana B porque su COMMIT fue el último, no hubo ningun
-- error ni advertencia.

--  PREGUNTA 1.2 — El bloqueo de fila SÍ funcionó: B esperó a que A
--  confirmara. Explique entonces por qué el banco perdió dinero de todos
--  modos.

--  El bloqueo evitó que las dos escrituras chocaran físicamente
-- pero no evitó que B escribiera un cálculo viejo entonces
-- hizo una resta sobre un saldo que ya no era vigente.

--  PREGUNTA 1.3 — En un marketplace este error vende una unidad de más.
--  En un banco, ¿de quién es la plata que se acaba de crear de la nada,
--  y quién la va a reclamar?

-- El cajero entregó 300,000, pero el saldo del sistema quedó
-- como si esos 300,000 nunca hubieran salido, entonces no se creó plata en sí,
-- el banco desembolso dinero que el sistema no descontó, lo cual se vuelve
-- un pasivo fantasma que el cliente puede volver a gastar.


-- #####################################################################
-- EJERCICIO 1.2 — Defensa pesimista: SELECT ... FOR UPDATE
-- #####################################################################

-- PASO 1  (A)  Dejo la cuenta en un valor conocido
UPDATE cuenta SET saldo = 1000000, version = 0 WHERE id_cuenta = 1001;
COMMIT;

-- PASO 2  (A)  Leo Y bloqueo en la misma operación
SELECT id_cuenta, saldo
  FROM cuenta
 WHERE id_cuenta = 1001
   FOR UPDATE;

-- ... conexión B, PASO 3 ...

-- PASO 5  (A)  Descuento mis 300.000 y libero
UPDATE cuenta SET saldo = saldo - 300000 WHERE id_cuenta = 1001;
COMMIT;

-- ... conexión B, PASO 6 ...

-- PASO 8  (A)  Resultado
SELECT id_cuenta, saldo FROM cuenta WHERE id_cuenta = 1001;
--
--  PREGUNTA 1.4 — Ahora sí quedan 500.000. ¿Qué dos cosas cambiaron
--  respecto al ejercicio anterior? (pista: una es el FOR UPDATE, la otra
--  está dentro del UPDATE mismo)

--  El FOR UPDATE, porque A bloquea la fila desde que la lee, asi B espera
--  desde el SELECT y cuando  fin lee ya ve es el saldo actualizado.
--  También el UPDATE con el set que pasó de 700,000 a 300,000

--  PREGUNTA 1.5 — ¿Cuál fue el precio que se pagó por esta seguridad?
--  Piense en una cuenta empresarial de recaudo que recibe cientos de
--  consignaciones por minuto.

-- Ganamos seguridad pero perdemos velocidad, el FOR UPDATE nos
-- ayuda a que se bloquee la fila desde que se lee hasta que se hace
-- COMMIT. Pero si estamos en una cuenta empresarial de recaudo, nos
-- llegan muchas consignaciones por minuto sobre la misma cuenta, entonces
-- se irán haciendo en fila una detrás de otra, lo cual nos costará mucha espera.


-- #####################################################################
-- EJERCICIO 1.3 — Defensa optimista: columna de versión
--
-- Nadie bloquea nada. El choque se detecta al escribir.
-- #####################################################################

-- PASO 1  (A)  Reinicio
UPDATE cuenta SET saldo = 1000000, version = 0 WHERE id_cuenta = 1001;
COMMIT;

-- PASO 2  (A)  Leo el saldo y la versión.  NO bloqueo nada.
SELECT id_cuenta, saldo, version FROM cuenta WHERE id_cuenta = 1001;
--> Anote la versión que ve. Debe ser 0.
-- Versión 0 me sale

-- ... conexión B, PASO 3: lee lo mismo y escribe PRIMERO ...

-- PASO 5  (A)  Intento escribir con la versión que leí
UPDATE cuenta
   SET saldo   = saldo - 300000,
       version = version + 1
 WHERE id_cuenta = 1001
   AND version   = 0;              -- <-- la versión que leí en el PASO 2
COMMIT;
--
--  Mire el mensaje: ¿cuántas filas actualizó?
-- 0 filas actualizadas
-- PASO 6  (A)
SELECT id_cuenta, saldo, version FROM cuenta WHERE id_cuenta = 1001;
--
--  PREGUNTA 1.6 — Su UPDATE afectó 0 filas. ¿Qué debe hacer la
--  aplicación en ese momento, y qué NO debe hacer nunca?

-- No es un error, es una señal de que alguien más escribió
-- esa fila que yo leí e intenté escribir, mi versión ya no existe,
-- mi compañero la subió a 1.

-- Lo que no debe hacer es tratar ese 0 como si la operación nunca hubiera funcionado
-- Ni tampoco hacer un UPDATE sin el filtro de versión para que pase.

--  PREGUNTA 1.7 — Compare las dos defensas. ¿En qué producto del banco
--  usaría la pesimista y en cuál la optimista? Justifique con el nivel
--  de contención esperado, no con opiniones.

--  El pesimista lo deberíamos usar donde hayan pocas transacciones que compitan
-- por la misma fila al mismo tiempo, con un nivel de contención baja, ejemplo una
-- cuenta de ahorros personal.

-- El optimista cuando hay nivel de contención alta, porque muchas operaciones tocan
-- la fila en paralelo, ya sería para una cuenta de alto volumen.

-- #####################################################################
-- EJERCICIO 1.4 — Repartir la cola de compensación: SKIP LOCKED
--
-- Dos procesos de compensación toman transferencias de la misma cola.
-- No pueden procesar la misma dos veces, y no pueden quedarse esperando
-- el uno al otro: la ventana de compensación se cierra a una hora fija.
-- #####################################################################

-- PASO 1  (A)  Tomo 5 tareas y las marco como mías
SELECT id_tarea, id_transferencia
  FROM tarea_compensacion
 WHERE estado = 'PENDIENTE'
   AND ROWNUM <= 5
   FOR UPDATE SKIP LOCKED;
--  Nota de sintaxis: aquí se usa ROWNUM y no FETCH FIRST ... ROWS ONLY.
--  Oracle implementa FETCH FIRST como una vista en línea, y combinarlo
--  con FOR UPDATE devuelve ORA-02014. Para una cola de trabajo ROWNUM es
--  además lo correcto: no importa CUÁLES cinco tareas toma, importa que
--  sean cinco libres y que nadie más las tenga.
--> Anote los id_tarea que le tocaron.  NO confirme todavía.
-- los ids son 11,12,13,14,15

-- ... conexión B, PASO 2: pide 5 tareas y recibe OTRAS distintas ...

-- PASO 3  (A)  Marco las mías como compensadas y libero
UPDATE tarea_compensacion
   SET estado = 'COMPENSADA', tomada_por = 'PROCESO_A', fecha_toma = SYSTIMESTAMP
 WHERE id_tarea IN (11,12,13,14,15);      -- <-- reemplace por los ids que le tocaron
COMMIT;

-- PASO 5  (A)  Verificación conjunta
SELECT tomada_por, COUNT(*) AS tareas
  FROM tarea_compensacion WHERE estado = 'COMPENSADA'
 GROUP BY tomada_por;
--
--  PREGUNTA 1.8 — ¿Qué habría pasado sin SKIP LOCKED? Describa los dos
--  comportamientos posibles según se use FOR UPDATE simple o NOWAIT.

-- Con FOR UPDATE simple B ejecutaría la misma consulta y si su SELECT FOR UPDATE toma una fila que A
-- ya tiene bloqueada se queda esperando a que A confirme.

-- Con NOWAIT en vez de esperar B recibiría lo siguiente: ORA-00054: resource busy
-- Esto en el momento en que choca con una fila que A tenga bloqueada, no espera nada
-- y tampoco consigue tareas.

--  PREGUNTA 1.9 — En una compensación real, procesar dos veces la misma
--  transferencia significa mover la plata dos veces. ¿Qué le garantiza
--  SKIP LOCKED que no le garantizaría un reparto hecho en la aplicación
--  con un "WHERE MOD(id,2) = 0" para un proceso y "= 1" para el otro?

-- SKIP LOCKED garantiza exclusión basada en el estado real de la fila, entonces
-- nos da dos cosas que MOD(id,2) no nos da, se adapta a fallas, si un proceso muere
-- rollback, esas filas vuelvena  quedar libres y otro proceso las puede recoger.
-- Tampoco hay doble toma real, si A ya tomó la fila, B no puede tomarla también, sin
-- importar que IDs le tocarían por lógica de aplicación.


-- #####################################################################
-- EJERCICIO 1.5 — El bloqueo que nadie espera: FK sin índice
--
-- NOTIFICACION.ID_TRANSFERENCIA es llave foránea hacia TRANSFERENCIA
-- y NO está indexada.
-- #####################################################################

-- PASO 1  (A)  Registro la notificación de la transferencia 900001.
--   NO confirmo.
INSERT INTO notificacion (id_notificacion, id_transferencia, canal, enviada)
VALUES (9000002, 900002, 'SMS', 'S');

-- ... conexión B, PASO 2: intenta borrar la transferencia 900005, que no
--     tiene ninguna notificación ni ningún movimiento, y se queda esperando ...

-- PASO 3  (A)  Mientras B espera, mire el bloqueo.
--   TX = bloqueo de fila.  TM = bloqueo de TABLA.
SELECT l.sid, l.type,
       DECODE(l.lmode, 0,'ninguno',1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X') AS tiene,
       DECODE(l.request,0,'-',1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X')      AS pide
  FROM v$lock l JOIN v$session s ON s.sid = l.sid
 WHERE s.username = USER AND l.type IN ('TX','TM');
--> Si no tiene permisos sobre V$, el docente lo proyecta.

-- PASO 4  (A)  Libero
COMMIT;

-- PASO 6  (A)  Creo el índice que faltaba
CREATE INDEX ix_notif_transferencia ON notificacion (id_transferencia);

-- PASO 7  (A)  Repitan los pasos 1 y 2. Ahora B NO se bloquea.
--
--  PREGUNTA 1.10 — Explique por qué Oracle toma un bloqueo de TABLA sobre
--  el hijo cuando se borra un padre y la FK no está indexada.

--  Sin indice oracle no puede verificar rápido si hay fijos apuntando al padre se borra,
--  para no arriesgar integridad entonces bloquea toda la tabla hija en vez de solo la fila.

--  PREGUNTA 1.11 — Revise el esquema completo del Banco Andino. ¿Qué
--  OTRAS llaves foráneas están sin índice? ¿Cuáles de ellas son realmente
--  un problema en este negocio y cuáles no? Justifique pensando en qué
--  se borra y qué no se borra nunca en un banco.

-- Sin índice: casi todas las FK, solo movimiento.id_transferencia está indexada,
-- importan de verdad las que apuntan a tablas que sí se borran, solo transferencia
-- se borra en la operación normal, por eso notificación.id_transferencia es un riesgo real.
-- las demás nunca se boran físicamente, se inactivan así que su falta de índice es un riesgo teórico y no real.


-- #####################################################################
-- EJERCICIO 1.6 — Interbloqueo: las dos transferencias cruzadas
--
-- Este es el caso clásico de la banca, y no es hipotético: ocurre todos
-- los días. Dos clientes se transfieren plata mutuamente al mismo tiempo.
-- #####################################################################

-- Antes de empezar, deje las dos cuentas en un valor conocido
UPDATE cuenta SET saldo = 1000000, version = 0 WHERE id_cuenta IN (1001, 1002);
COMMIT;

-- PASO 1  (A)  Transferencia de la 1001 a la 1002: primero debito el origen
UPDATE cuenta SET saldo = saldo - 50000 WHERE id_cuenta = 1001;

-- ... conexión B, PASO 2: hace la transferencia inversa, 1002 -> 1001,
--     y debita PRIMERO la 1002 ...

-- PASO 3  (A)  Ahora acredito el destino: la cuenta 1002, que B ya tiene
UPDATE cuenta SET saldo = saldo + 50000 WHERE id_cuenta = 1002;
--> Me quedo esperando.

-- ... conexión B, PASO 4: pide la 1001, que yo tengo -> ciclo cerrado ...

--> En segundos, UNA de las dos recibe:
--     ORA-00060: deadlock detected while waiting for resource

ROLLBACK;
--
--  PREGUNTA 1.12 — Oracle abortó UNA sentencia, no la transacción
--  completa. ¿En qué estado queda la sesión víctima y qué debe hacer?
--  ¿Qué pasa si la aplicación asume que Oracle deshizo todo?

--  La sesión victima queda con su sentencia fallida deshecha, pero la transacción
-- sigue abierta con los cambios previos aún sin confirmar, entonces debe hacer ROLLBACK
-- para limpiar todo, si la app asume que oracle hizo todo y sigue como si nada esa transacción
-- queda colgada a medias, o en peor caso podría hacer commit de un estado parcial e inconsistente.

--  PREGUNTA 1.13 — Escriba la regla de diseño, en una frase, que habría
--  hecho imposible este interbloqueo. Después dígala en términos de
--  código: ¿qué línea concreta hay que agregar antes de los dos UPDATE?

-- Siempre bloquear las cuentas en el mismo orden sin importar cuál es origen o destino.
--SELECT ... FROM cuenta WHERE id_cuenta IN (1001,1002) ORDER BY id_cuenta FOR UPDATE;
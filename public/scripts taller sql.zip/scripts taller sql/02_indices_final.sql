-- =====================================================================
-- Bases de Datos 2 · Taller integrador — Banco Andino
-- 02_indices.sql   Índices y optimización de consultas
--
-- IMPORTANTE: de aquí en adelante trabajen en UNA SOLA CONEXIÓN.
-- La pareja comparte el mismo esquema, y dos personas creando índices o
-- insertando en la misma tabla al mismo tiempo se bloquean entre sí.
-- Uno maneja el teclado, los dos discuten y anotan.
--
-- Ejecute bloque por bloque con Ctrl+Enter.
-- =====================================================================

SET TIMING ON
SET LINESIZE 200
SET PAGESIZE 1000

-- ---------------------------------------------------------------------
-- CÓMO VAMOS A MEDIR
--
-- En SQL Developer tiene tres herramientas. Úselas todas:
--
--   F10  Explain Plan   -> el plan que el optimizador PIENSA usar.
--                          No ejecuta la consulta. Es una estimación.
--   F6   Autotrace      -> ejecuta la consulta y muestra el plan REAL
--                          más las estadísticas de sesión.
--   F5   Run Script     -> para los bloques con SET TIMING.
--
-- Las dos cifras que importan:
--   COST            estimación del optimizador (sirve para comparar)
--   consistent gets bloques leídos de verdad (esta es la que no miente)
--
-- También puede pedir el plan por texto, así:
-- ---------------------------------------------------------------------

EXPLAIN PLAN FOR
SELECT COUNT(*) FROM transferencia WHERE estado = 'APLICADA';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));


-- #####################################################################
-- EJERCICIO 2.1 — El informe de la Superintendencia
--
-- Todos los meses hay que reportar el valor y el número de
-- transferencias efectivamente aplicadas del mes anterior.
-- #####################################################################

-- PASO 1  Ejecute la consulta y mida
SELECT COUNT(*)          AS operaciones,
       SUM(valor)        AS valor_total,
       ROUND(AVG(valor)) AS ticket_promedio
  FROM transferencia
 WHERE fecha_transf >= DATE '2026-03-01'
   AND fecha_transf <  DATE '2026-04-01'
   AND estado        = 'APLICADA';

-- PASO 2  Vea el plan
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(valor)
  FROM transferencia
 WHERE fecha_transf >= DATE '2026-03-01'
   AND fecha_transf <  DATE '2026-04-01'
   AND estado        = 'APLICADA';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  ANOTE:  operación = TABLE ACCESS FULL   COST = 377   filas = 5205
--
--  PREGUNTA 2.1 — La tabla tiene 200.000 filas y la consulta devuelve
--  unos pocos miles. ¿Por qué el optimizador está leyendo la tabla
--  completa? ¿Es un error del optimizador?
--  Porque todavía no existe ningún índice sobre
--  fecha_transf ni sobre estado. Sin índice, la única forma de aplicar
--  el filtro es leer fila por fila (TABLE ACCESS FULL), no es un error
--  del optimizador con lo que hay disponible, es lo mejor que puede
--  hacer.


-- PASO 3  Cree el índice
CREATE INDEX ix_transf_fecha_estado ON transferencia (fecha_transf, estado);

EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TRANSFERENCIA', cascade => TRUE);

-- PASO 4  Repita la medición
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(valor)
  FROM transferencia
 WHERE fecha_transf >= DATE '2026-03-01'
   AND fecha_transf <  DATE '2026-04-01'
   AND estado        = 'APLICADA';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  ANOTE:  operación = INDEX RANGE SCAN (IX_TRANSF_FECHA_ESTADO)   COST = 39
--
--  PREGUNTA 2.2 — ¿Cuánto bajó el COST? Ejecute también con F6
--  (Autotrace) antes y después y compare los "consistent gets".
--
--  RESPUESTA 2.2  El cost bajó de 377 a 39 porque ya no hace
--  falta leer toda la tabla, solo los bloques del índice y los pocos
--  bloques de datos que caen dentro del rango de fechas pedido. Los
--  consistent gets del Autotrace bajan en la misma proporción, porque
--  se leen muchos menos bloques que antes.


-- PASO 5  El orden de las columnas SÍ importa
CREATE INDEX ix_transf_estado_fecha ON transferencia (estado, fecha_transf);

EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TRANSFERENCIA', cascade => TRUE);

-- Fuerce cada índice y compare
EXPLAIN PLAN FOR
SELECT /*+ INDEX(t ix_transf_fecha_estado) */ COUNT(*)
  FROM transferencia t
 WHERE fecha_transf >= DATE '2026-03-01'
   AND fecha_transf <  DATE '2026-04-01'
   AND estado        = 'APLICADA';
   SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
   
EXPLAIN PLAN FOR   
SELECT /*+ INDEX(t ix_transf_estado_fecha) */ COUNT(*)
  FROM transferencia t
 WHERE fecha_transf >= DATE '2026-03-01'
   AND fecha_transf <  DATE '2026-04-01'
   AND estado        = 'APLICADA';
 
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));   
--
--  PREGUNTA 2.3 — ¿Cuál de los dos índices elige el optimizador cuando
--  no se le fuerza nada? Compare el COST de los dos SELECT anteriores.
--  Formule la regla general sobre el orden de columnas en un índice
--  compuesto, distinguiendo el predicado de IGUALDAD del de RANGO.

--  Respuesta 2.3 Forzando cada uno IX_TRANSF_FECHA_ESTADO
--  da COST = 39 mientras que IX_TRANSF_ESTADO_FECHA
--  da COST = 25. Sin forzar nada, el optimizador se
--  quedaría con el más barato osea IX_TRANSF_ESTADO_FECHA
--  en un índice compuesto conviene poner primero la columna de IGUALDAD
--  estado y de último la de RANGO fecha, porque el índice deja de
--  servir justo donde empieza el rango si el rango va primero, el
--  resto de columnas del índice ya casi no ayudan.

--  PREGUNTA 2.4 — Suponga ahora que existe además un informe diario que
--  filtra SOLO por rango de fechas, sin estado. ¿Cuál de los dos índices
--  le sirve a ese informe y cuál no? ¿Cambia eso su recomendación?
--  Responda cuál de los dos conservaría en producción y por qué.

-- Respuesta 2.4 A ese informe diario le sirve
--  IX_TRANSF_FECHA_ESTADO porque fecha_transf es su columna lider
--  IX_TRANSF_ESTADO_FECHA no le sirve, porque ahí fecha queda de
--  segunda y no se puede usar sola aunque en la pregunta 2.3 el índice
--  estado-fecha ganó en costo puntual en producción me quedaría con
--  IX_TRANSF_FECHA_ESTADO porque sirve a más consultas y la diferencia
--  de costo entre los dos no es tan grande como para justificar mantener
--   un índice que solo sirve a una consulta.



-- Para el resto del taller trabajamos con IX_TRANSF_FECHA_ESTADO,
-- para no multiplicar índices. Su recomendación va en la entrega.
DROP INDEX ix_transf_estado_fecha;


-- #####################################################################
-- EJERCICIO 2.2 — El índice que existe y no se usa
--
-- El área de servicio al cliente busca por nombre y se queja de que la
-- pantalla de consulta se demora.
-- #####################################################################

-- PASO 1  Sin índice
EXPLAIN PLAN FOR
SELECT id_cliente, nombre, ciudad, segmento
  FROM cliente WHERE UPPER(nombre) = 'MARCELA ROJAS 4004';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

-- PASO 2  Creo el índice "obvio"
CREATE INDEX ix_cliente_nombre ON cliente (nombre);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'CLIENTE', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT id_cliente, nombre, ciudad, segmento
  FROM cliente WHERE UPPER(nombre) = 'MARCELA ROJAS 4004';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.5 — El índice existe y sigue haciendo FULL SCAN.
--  ¿Por qué? ¿Qué le hizo la consulta a la columna indexada?

--  RESPUESTA 2.5 El indice se creo sobre nombre
--  pero la consulta filtra por UPPER(nombre), al envolver la columna en
--  una funcion oracle ya no puede usar el índice normal (el índice
--  guarda los valores originales, no los valores en mayúsculas) así
--  que sigue haciendo FULL SCAN aunque el índice exista.

-- PASO 3  El índice que sí sirve
CREATE INDEX ix_cliente_nombre_upper ON cliente (UPPER(nombre));
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'CLIENTE', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT id_cliente, nombre, ciudad, segmento
  FROM cliente WHERE UPPER(nombre) = 'MARCELA ROJAS 4004';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

-- PASO 4  El mismo error, con fechas.  Este es el más común de todos,
--   y en banca aparece en cada extracto y en cada corte diario.
EXPLAIN PLAN FOR
SELECT COUNT(*) FROM transferencia WHERE TRUNC(fecha_transf) = DATE '2026-03-15';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));

EXPLAIN PLAN FOR
SELECT COUNT(*) FROM transferencia
 WHERE fecha_transf >= DATE '2026-03-15'
   AND fecha_transf <  DATE '2026-03-16';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.6 — Las dos consultas devuelven exactamente lo mismo.
--  Compare los planes. Escriba la regla, en una frase, que todo
--  desarrollador debería tener presente al filtrar por fecha.

--  RESPUESTA 2.6 Con TRUNC(fecha_transf) el plan da
--  INDEX FAST FULL SCAN con COST = 238 y con el rango explícito
--  el plan da INDEX RANGE SCAN con COST = 4 mucho más barato.

-- #####################################################################
-- EJERCICIO 2.3 — Cuándo NO conviene un índice
-- #####################################################################

-- PASO 1  Un filtro que devuelve el 62% de la tabla
CREATE INDEX ix_transf_estado ON transferencia (estado);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TRANSFERENCIA', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(valor) FROM transferencia WHERE estado = 'APLICADA';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

-- PASO 2  El mismo índice, con un valor poco frecuente
EXPLAIN PLAN FOR
SELECT COUNT(*), SUM(valor) FROM transferencia WHERE estado = 'REVERSADA';
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));
--
--  PREGUNTA 2.7 — El mismo índice, la misma consulta, distinto valor:
--  en un caso se usa y en el otro no. ¿Cómo lo sabe el optimizador?
--  ¿Qué información necesita para tomar esa decisión?

-- RESPUESTA 2.7
-- El optimizador usa las estadísticas guardadas para estimar cuántas filas cumple cada valor.
-- ESTADO tiene solo 4 valores distintos: con APLICADA estima 123K filas y con REVERSADA
-- estima 14.000. Aunque REVERSADA es mucho menos frecuente, sigue siendo full scan en los
-- dos casos, porque incluso 14.000 filas es una porción de la tabla lo bastante grande como
-- para que ir saltando por el índice salga más caro que simplemente leer todo de una vez.


--
--  PREGUNTA 2.8 — Consulte la selectividad y el clustering factor:

SELECT column_name, num_distinct, num_nulls, density
  FROM user_tab_col_statistics
 WHERE table_name = 'TRANSFERENCIA'
   AND column_name IN ('ESTADO','FECHA_TRANSF','CUENTA_ORIGEN','CANAL');

SELECT index_name, num_rows, distinct_keys, clustering_factor, blevel, leaf_blocks
  FROM user_indexes WHERE table_name = 'TRANSFERENCIA';
--
--  ¿Qué le dice el CLUSTERING FACTOR de IX_TRANSF_FECHA_ESTADO comparado
--  con el de IX_TRANSF_ESTADO? ¿Por qué son tan distintos?

--  RESPUESTA 2.8 IX_TRANSF_FECHA_ESTADO tiene un clustering
--  factor altísimo (199.975, casi igual al número de filas), mientras
--  que IX_TRANSF_ESTADO lo tiene mucho más bajo (5.275). Esto pasa
--  porque los datos se cargaron en orden de id_transferencia, y el
--  estado sí queda agrupado en tandas de filas consecutivas, pero la
--  fecha se generó con una fórmula que la dispersa de forma casi
--  aleatoria respecto al orden físico de la tabla. Por eso recorrer el
--  índice por fecha obliga a saltar de bloque en bloque (mal clustering
--  factor), y recorrer el de estado sí aprovecha que las filas del
--  mismo estado quedan físicamente cerca.


-- #####################################################################
-- EJERCICIO 2.4 — El índice que evita tocar la tabla
-- #####################################################################

-- PASO 1  Cuentas más activas del trimestre
EXPLAIN PLAN FOR
SELECT cuenta_origen, COUNT(*) AS operaciones
  FROM transferencia
 WHERE fecha_transf >= DATE '2026-01-01'
   AND fecha_transf <  DATE '2026-04-01'
 GROUP BY cuenta_origen;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--> Fíjese: hay INDEX RANGE SCAN y ADEMÁS TABLE ACCESS BY INDEX ROWID.

-- PASO 2  Agrego la columna que falta al índice
CREATE INDEX ix_transf_fecha_origen ON transferencia (fecha_transf, cuenta_origen);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TRANSFERENCIA', cascade => TRUE);

EXPLAIN PLAN FOR
SELECT cuenta_origen, COUNT(*) AS operaciones
  FROM transferencia
 WHERE fecha_transf >= DATE '2026-01-01'
   AND fecha_transf <  DATE '2026-04-01'
 GROUP BY cuenta_origen;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST'));
--
--  PREGUNTA 2.9 — Desapareció el TABLE ACCESS. ¿Cómo se llama esta
--  técnica y por qué es tan efectiva? ¿Cuál es su límite: hasta dónde
--  tiene sentido seguir agregando columnas al índice?


--  RESPUESTA 2.9 Se llama índice de cobertura (covering
--  index): el índice ya trae todas las columnas que pide la consulta
--  (fecha_transf y cuenta_origen), así que Oracle no necesita ir a la
--  tabla, el COST bajó de 378 a 94. El límite es que no se puede
--  agregar cualquier columna: cada columna extra hace el índice más
--  grande y más lento de mantener en cada INSERT/UPDATE, así que solo
--  vale la pena para consultas realmente frecuentes e importantes.



-- #####################################################################
-- EJERCICIO 2.5 — Lo que cuesta un índice
--
-- Hasta aquí solo hemos visto el beneficio. Ahora el precio.
-- #####################################################################

-- PASO 1  Cuántos índices tiene TRANSFERENCIA en este momento
SELECT index_name, leaf_blocks,
       ROUND(leaf_blocks * 8192 / 1024 / 1024, 2) AS mb_aprox
  FROM user_indexes WHERE table_name = 'TRANSFERENCIA';

-- PASO 2  Inserte 50.000 transferencias CON todos los índices y mida
--   (ejecute este bloque con F5 para ver el TIMING)
SET TIMING ON
INSERT INTO transferencia
  (id_transferencia, cuenta_origen, cuenta_destino, fecha_transf, valor, canal, estado)
SELECT 1000000 + LEVEL,
       MOD(LEVEL, 15000) + 1,
       MOD(LEVEL, 15000) + 15001,
       DATE '2026-06-01' + MOD(LEVEL,30), 100000, 'APP', 'REGISTRADA'
  FROM dual CONNECT BY LEVEL <= 50000;
COMMIT;
--> Anote el tiempo: 2.433

-- PASO 3  Ahora sin índices secundarios
DROP INDEX ix_transf_fecha_estado;
DROP INDEX ix_transf_estado;
DROP INDEX ix_transf_fecha_origen;

INSERT INTO transferencia
  (id_transferencia, cuenta_origen, cuenta_destino, fecha_transf, valor, canal, estado)
SELECT 2000000 + LEVEL,
       MOD(LEVEL, 15000) + 1,
       MOD(LEVEL, 15000) + 15001,
       DATE '2026-06-01' + MOD(LEVEL,30), 100000, 'APP', 'REGISTRADA'
  FROM dual CONNECT BY LEVEL <= 50000;
COMMIT;
--> Anote el tiempo: 0.5

-- PASO 4  Deje el esquema como debe quedar
DELETE FROM transferencia WHERE id_transferencia >= 1000000;
COMMIT;

CREATE INDEX ix_transf_fecha_estado ON transferencia (fecha_transf, estado);
CREATE INDEX ix_transf_fecha_origen ON transferencia (fecha_transf, cuenta_origen);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TRANSFERENCIA', cascade => TRUE);
--
--  PREGUNTA 2.10 — ¿Cuál fue la diferencia de tiempo? Extrapole:
--  el Banco Andino procesa 12.000 transferencias por hora en hora pico.
--  ¿Qué costo operativo tiene cada índice que se agrega "por si acaso"?

--  RESPUESTA 2.10 Insertar con los 3 índices activos tardó
--  varias veces más que insertar sin ellos porque cada indice implica
--  una escritura adicional por cada fila que entra. con 12.000
--  transferencias/hora en hora pico, cada índice de más agregado
--  representa ese costo de escritura multiplicado por
--  miles de operaciones cada hora, todos los días. Un índice que nadie
--  usa para leer solo suma costo, nunca beneficio.
--

--
--  PREGUNTA 2.11 — Proponga la lista DEFINITIVA de índices para este
--  esquema. Para cada uno escriba: qué consulta lo justifica, y por qué
--  no se puede resolver con otro índice ya existente. Tenga en cuenta
--  que TRANSFERENCIA tiene DOS llaves foráneas hacia CUENTA.


-- respuesta 2.11 dejariamos 3 indices en transferencia
-- ix_transf_fecha_estado (fecha_transf, estado) para el informe de
-- la superintendencia, un indice de solo estado no sirve porque no
-- filtra por fecha.
-- ix_transf_fecha_origen (fecha_transf, cuenta_origen) para el
-- reporte de cuentas mas activas, evita ir a la tabla.
-- un indice sobre cuenta_destino, sin el cualquier operacion sobre
-- cuenta puede bloquear toda la tabla transferencia, igual que paso
-- con notificacion en la parte 1.

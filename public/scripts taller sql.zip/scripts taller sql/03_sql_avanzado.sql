-- =====================================================================
-- Bases de Datos 2 · Taller integrador — Banco Andino
-- 03_sql_avanzado.sql   SQL analítico, jerárquico y MERGE
--
-- Trabajen en UNA SOLA CONEXIÓN: la pareja comparte el esquema.
-- Cada bloque trae una consulta RESUELTA que sirve de modelo, y una
-- consulta que ustedes deben ESCRIBIR. Complete las que dicen ESCRIBA.
-- =====================================================================

SET LINESIZE 220
SET PAGESIZE 60
SET TIMING ON


-- #####################################################################
-- EJERCICIO 3.1 — Ranking dentro de grupos
--
-- La vicepresidencia comercial quiere los 3 productos que más saldo
-- captan dentro de cada FAMILIA de productos, solo cuentas activas.
-- #####################################################################

-- MODELO (resuelto)
WITH captacion AS (
  SELECT f.id_producto  AS id_familia,
         f.nombre       AS familia,
         p.id_producto,
         p.nombre       AS producto,
         SUM(c.saldo)   AS saldo_captado,
         COUNT(*)       AS cuentas
    FROM cuenta c
    JOIN catalogo_producto p ON p.id_producto = c.id_producto
    JOIN catalogo_producto f ON f.id_producto = p.id_padre
   WHERE c.estado = 'ACTIVA'
   GROUP BY f.id_producto, f.nombre, p.id_producto, p.nombre
)
SELECT familia, producto, cuentas, ROUND(saldo_captado) AS saldo_captado, puesto
  FROM (SELECT v.*,
               DENSE_RANK() OVER (PARTITION BY id_familia
                                  ORDER BY saldo_captado DESC) AS puesto
          FROM captacion v)
 WHERE puesto <= 3
 ORDER BY familia, puesto;

--
--  PREGUNTA 3.1 — Cambie DENSE_RANK por RANK y luego por ROW_NUMBER.
--  Explique en qué se diferencian los tres cuando hay empates, y cuál
--  usaría usted para un "top 3" que debe devolver exactamente 3 filas.

-- La diferencia es que RANK da el mismo puesto a los empatados pero va saltando números,
-- DENSE_RANK da el mismo puesto pero no salta.
-- ROW_NUMBER solo asigna puestos consecutivos únicamente, entonces este se usaría para devolver
-- exactamente 3 filas, con los otros dos podemos terminar con 4 o más filas.


--  ESCRIBA 3.1 — La misma consulta, pero mostrando además qué porcentaje
--  representa cada producto sobre el saldo total captado por su familia.
--  Use RATIO_TO_REPORT o una función de ventana con SUM() OVER.
--  Cuidado: el porcentaje debe ser sobre la familia COMPLETA, no sobre
--  el top 3.

WITH captacion AS (
  SELECT f.id_producto  AS id_familia,
         f.nombre       AS familia,
         p.id_producto,
         p.nombre       AS producto,
         SUM(c.saldo)   AS saldo_captado,
         COUNT(*)       AS cuentas
    FROM cuenta c
    JOIN catalogo_producto p ON p.id_producto = c.id_producto
    JOIN catalogo_producto f ON f.id_producto = p.id_padre
   WHERE c.estado = 'ACTIVA'
   GROUP BY f.id_producto, f.nombre, p.id_producto, p.nombre
),
rankeado AS (
  SELECT v.*,
         DENSE_RANK() OVER (PARTITION BY id_familia
                             ORDER BY saldo_captado DESC) AS puesto,
         RATIO_TO_REPORT(saldo_captado) OVER (PARTITION BY id_familia) AS pct_familia
    FROM captacion v
)
SELECT familia, producto, cuentas,
       ROUND(saldo_captado) AS saldo_captado,
       puesto,
       ROUND(pct_familia * 100, 2) AS pct_sobre_familia
  FROM rankeado
 WHERE puesto <= 3
 ORDER BY familia, puesto;


-- #####################################################################
-- EJERCICIO 3.2 — Series de tiempo: acumulado y variación
--
-- Riesgo operativo quiere la evolución mensual del valor transferido
-- durante 2026, con el acumulado del año y la variación contra el mes
-- anterior. Es la base de las alertas por comportamiento atípico.
-- #####################################################################

-- MODELO (resuelto)
WITH mensual AS (
  SELECT TRUNC(fecha_transf, 'MM') AS mes,
         SUM(valor)                AS valor_transferido,
         COUNT(*)                  AS operaciones
    FROM transferencia
   WHERE fecha_transf >= DATE '2026-01-01'
     AND fecha_transf <  DATE '2027-01-01'
     AND estado = 'APLICADA'
   GROUP BY TRUNC(fecha_transf, 'MM')
)
SELECT TO_CHAR(mes,'YYYY-MM')                          AS mes,
       operaciones,
       ROUND(valor_transferido)                        AS valor,
       ROUND(SUM(valor_transferido) OVER (ORDER BY mes
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) AS acumulado,
       ROUND(LAG(valor_transferido) OVER (ORDER BY mes)) AS mes_anterior,
       ROUND(100 * (valor_transferido - LAG(valor_transferido) OVER (ORDER BY mes))
                 / NULLIF(LAG(valor_transferido) OVER (ORDER BY mes),0), 1) AS var_pct
  FROM mensual
 ORDER BY mes;

--
--  PREGUNTA 3.2 — ¿Qué diferencia hay entre
--     ROWS  BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
--  y  RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW ?
--  Constrúyase un caso donde den resultados distintos.

-- La diferencia es que ROWS cuenta filas físicas, exactamente la fila actual y las anteriores,
-- sin importar si el valor de la columna del ORDER BY se repite.
-- RANGE agrupa por valor lógico entonces si hay empate en la columna del ORDER BY,
-- todas las filas con ese mismo valor entran juntas en el cálculo, aunque sean varias.

-- CASO:
SELECT id_movimiento, fecha_mov, tipo, valor,
       SUM(valor) OVER (ORDER BY fecha_mov
                         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS acum_rows,
       SUM(valor) OVER (ORDER BY fecha_mov
                         RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS acum_range
  FROM movimiento
 WHERE id_transferencia = (SELECT MIN(id_transferencia)
                              FROM transferencia WHERE estado = 'APLICADA')
 ORDER BY fecha_mov;


--  ESCRIBA 3.2 — Agregue una columna con el promedio móvil de los
--  últimos 3 meses (mes actual y los dos anteriores), que es la línea
--  base contra la que riesgo compara cada mes.
WITH mensual AS (
  SELECT TRUNC(fecha_transf, 'MM') AS mes,
         SUM(valor)                AS valor_transferido,
         COUNT(*)                  AS operaciones
    FROM transferencia
   WHERE fecha_transf >= DATE '2026-01-01'
     AND fecha_transf <  DATE '2027-01-01'
     AND estado = 'APLICADA'
   GROUP BY TRUNC(fecha_transf, 'MM')
)
SELECT TO_CHAR(mes,'YYYY-MM')                          AS mes,
       operaciones,
       ROUND(valor_transferido)                        AS valor,
       ROUND(SUM(valor_transferido) OVER (ORDER BY mes
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) AS acumulado,
       ROUND(LAG(valor_transferido) OVER (ORDER BY mes)) AS mes_anterior,
       ROUND(100 * (valor_transferido - LAG(valor_transferido) OVER (ORDER BY mes))
                 / NULLIF(LAG(valor_transferido) OVER (ORDER BY mes),0), 1) AS var_pct,
       ROUND(AVG(valor_transferido) OVER (ORDER BY mes
             ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)) AS promedio_movil_3m
  FROM mensual
 ORDER BY mes;


-- #####################################################################
-- EJERCICIO 3.3 — La misma respuesta, dos planes muy distintos
--
-- Se necesita, por cada cliente PREFERENCIAL, su última transferencia.
-- #####################################################################

-- VERSIÓN A — subconsulta correlacionada  (la que sale sola al escribir)
EXPLAIN PLAN FOR
SELECT cl.id_cliente, cl.nombre, t.id_transferencia, t.fecha_transf, t.valor
  FROM cliente       cl
  JOIN cuenta        c ON c.id_cliente = cl.id_cliente
  JOIN transferencia t ON t.cuenta_origen = c.id_cuenta
 WHERE cl.segmento = 'PREFERENCIAL'
   AND t.fecha_transf = (SELECT MAX(t2.fecha_transf)
                           FROM transferencia t2
                           JOIN cuenta c2 ON c2.id_cuenta = t2.cuenta_origen
                          WHERE c2.id_cliente = cl.id_cliente);

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));


-- VERSIÓN B — función analítica
EXPLAIN PLAN FOR
SELECT id_cliente, nombre, id_transferencia, fecha_transf, valor
  FROM (SELECT cl.id_cliente, cl.nombre, t.id_transferencia,
               t.fecha_transf, t.valor,
               ROW_NUMBER() OVER (PARTITION BY cl.id_cliente
                                  ORDER BY t.fecha_transf DESC) AS rn
          FROM cliente       cl
          JOIN cuenta        c ON c.id_cliente = cl.id_cliente
          JOIN transferencia t ON t.cuenta_origen = c.id_cuenta
         WHERE cl.segmento = 'PREFERENCIAL')
 WHERE rn = 1;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));


--
--  PREGUNTA 3.3 — Compare los dos planes. ¿Cuántas veces se lee
--  TRANSFERENCIA en cada versión? ¿Cuál es el COST de cada una?

-- En las dos TRANSFERENCIA se lee una sola vez, esto es porque el optimizador
-- transformó la subconsulta correlacionada en algo equivalente a una función anlítica.
-- El COST en A es 1268, en B 1160.

--
--  PREGUNTA 3.4 — Las dos consultas NO son totalmente equivalentes:
--  hay un caso en el que devuelven distinto número de filas. ¿Cuál es?
--  (pista: piense en un cliente que hizo dos transferencias el mismo
--  día a la misma hora, algo perfectamente normal en un pago de nómina)

-- El caso seria un cliente con dos transferencias que empatan en fecha_transf.
-- La versión A compara t.fecha_transf = MAX(...). Si dos transferencias tienen la
-- fecha máxima empatada, se devuelven 2 filas para ese cliente.
-- La versión B usa ROW_NUMBER() ... ORDER BY fecha_transf DESC y filtra rn = 1. 
-- ROW_NUMBER nunca reparte el mismo puesto entre empatados, entonces devuelve 1 fila.

-- #####################################################################
-- EJERCICIO 3.4 — Jerarquías: la CTE recursiva
--
-- El catálogo tiene tres niveles: línea de negocio, familia y producto.
-- #####################################################################

-- MODELO (resuelto) — ruta completa de cada nodo del catálogo
WITH arbol (id_producto, nombre, id_padre, nivel, ruta) AS (
  SELECT id_producto, nombre, id_padre, 1, CAST(nombre AS VARCHAR2(400))
    FROM catalogo_producto
   WHERE id_padre IS NULL
  UNION ALL
  SELECT c.id_producto, c.nombre, c.id_padre, a.nivel + 1,
         a.ruta || ' > ' || c.nombre
    FROM catalogo_producto c
    JOIN arbol a ON c.id_padre = a.id_producto
)
SELECT LPAD(' ', (nivel-1)*3) || nombre AS jerarquia, nivel, ruta
  FROM arbol
 ORDER BY ruta;

-- El equivalente con CONNECT BY, sintaxis propia de Oracle
SELECT LPAD(' ', (LEVEL-1)*3) || nombre AS jerarquia,
       LEVEL AS nivel,
       SYS_CONNECT_BY_PATH(nombre, ' > ') AS ruta
  FROM catalogo_producto
 START WITH id_padre IS NULL
CONNECT BY PRIOR id_producto = id_padre
 ORDER SIBLINGS BY nombre;

--
--  PREGUNTA 3.5 — ¿Qué ventaja tiene la CTE recursiva sobre CONNECT BY?
--  ¿Y qué le da CONNECT BY que la CTE no?

-- La ventaja que tiene es que es SQL estándar y deja calcular cualquier cosa
-- de forma incremental mientras se sube o baja en el árbol.
-- La ventaja de CONNECT BY es que es mucho más conciso y trae herramientas nativas
-- para usar sin escribirlas, también detección de ciclos sin tener que programarlos.

--  ESCRIBA 3.3 — Saldo total captado por LÍNEA DE NEGOCIO.
--  Es decir: el saldo de "Cuenta de ahorros" debe sumar dentro de
--  "Banca Personas". Use la CTE recursiva para resolver a qué línea
--  pertenece cada producto hoja, y únala con los saldos de CUENTA.
--  Muestre además cuántas cuentas activas tiene cada línea.

WITH linea (id_producto, nombre_linea, id_linea) AS (
  SELECT id_producto, nombre AS nombre_linea, id_producto AS id_linea
    FROM catalogo_producto
   WHERE id_padre IS NULL
  UNION ALL
  SELECT c.id_producto, l.nombre_linea, l.id_linea
    FROM catalogo_producto c
    JOIN linea l ON c.id_padre = l.id_producto
)
SELECT l.nombre_linea                AS linea_negocio,
       COUNT(*)                      AS cuentas_activas,
       ROUND(SUM(cu.saldo))          AS saldo_captado
  FROM cuenta cu
  JOIN linea  l ON l.id_producto = cu.id_producto
 WHERE cu.estado = 'ACTIVA'
 GROUP BY l.nombre_linea
 ORDER BY saldo_captado DESC;
 
-- #####################################################################
-- EJERCICIO 3.5 — MERGE: aplicar los ajustes del cierre mensual
--
-- Cada fin de mes se aplican intereses y cuotas de manejo. La tabla
-- AJUSTE_SALDO ya los tiene cargados.
-- #####################################################################

-- PASO 1  Antes
SELECT ROUND(SUM(saldo)) AS saldo_total, COUNT(*) AS cuentas FROM cuenta;
SELECT concepto, COUNT(*), SUM(delta) FROM ajuste_saldo GROUP BY concepto;

-- MODELO (resuelto)
MERGE INTO cuenta c
USING (SELECT id_cuenta, SUM(delta) AS delta
         FROM ajuste_saldo
        GROUP BY id_cuenta) a
   ON (c.id_cuenta = a.id_cuenta)
 WHEN MATCHED THEN
   UPDATE SET c.saldo   = GREATEST(c.saldo + a.delta, 0),
              c.version = c.version + 1;
--> Mire el mensaje de SQL Developer: cuántas filas fusionó.
COMMIT;

-- PASO 2  Después
SELECT ROUND(SUM(saldo)) AS saldo_total FROM cuenta;

--
--  PREGUNTA 3.6 — ¿Por qué se agrupa la tabla de ajustes dentro del
--  USING en lugar de usarla directamente? ¿Qué error da Oracle si una
--  misma cuenta aparece dos veces en el origen?

-- Se agrupa porque MERGE exige que el USING entregue como máximo una fila
-- por cada fila del destino que participa en el WHEN MATCHED.
-- El error que da Oracle es ORA-30926: unable to get a stable set of rows in the source tables
-- No nos dice "cuenta duplicada", dice que no puede garantizar una relación 1 a 1 estable entre origen y destino.

--  PREGUNTA 3.7 — El GREATEST(..., 0) evita que el saldo quede negativo.
--  En un banco eso NO es una solución: si una cuota de manejo excede el
--  saldo, truncar a cero significa que el banco regaló la diferencia.
--  ¿Qué haría usted en un sistema real? Proponga el mecanismo, no solo
--  la crítica.

-- En vez de truncar a cero, aplicaríamos solo lo que el saldo permite, y registrar el faltante
-- como una obligación distinta, se actualizaría saldo hasta el máximo que no lo dejee negativo.
-- También insertar la diferencia no aplicada en una tabla de cartera/ajustes pendientes para que
-- cobranza o el ciclo del mes siguiente la gestione.
-- Así el banco no regala nada, simplemente lo deja documentado y pendiente de cobro.

--  ESCRIBA 3.4 — Reescriba el MERGE para que las cuentas cuyo ajuste no
--  se pueda aplicar completo NO se toquen, y en cambio queden
--  identificadas. Pista: la cláusula WHERE de la actualización dentro
--  del MERGE, más una consulta que liste las excluidas.
MERGE INTO cuenta c
USING (SELECT id_cuenta, SUM(delta) AS delta
         FROM ajuste_saldo
        GROUP BY id_cuenta) a
   ON (c.id_cuenta = a.id_cuenta)
 WHEN MATCHED THEN
   UPDATE SET c.saldo   = c.saldo + a.delta,
              c.version = c.version + 1
        WHERE c.saldo + a.delta >= 0;

COMMIT;


SELECT c.id_cuenta, c.saldo AS saldo_actual, a.delta AS ajuste_pendiente,
       c.saldo + a.delta AS saldo_resultante
  FROM cuenta c
  JOIN (SELECT id_cuenta, SUM(delta) AS delta
          FROM ajuste_saldo
         GROUP BY id_cuenta) a ON a.id_cuenta = c.id_cuenta
 WHERE c.saldo + a.delta < 0;


-- #####################################################################
-- EJERCICIO 3.6 — PIVOT y LISTAGG
-- #####################################################################

-- MODELO (resuelto) — valor transferido por canal y trimestre, en columnas
SELECT *
  FROM (SELECT canal,
               'T' || TO_CHAR(fecha_transf,'Q') AS trimestre,
               valor
          FROM transferencia
         WHERE fecha_transf >= DATE '2026-01-01'
           AND fecha_transf <  DATE '2027-01-01'
           AND estado = 'APLICADA')
 PIVOT (ROUND(SUM(valor)) FOR trimestre IN ('T1' AS t1, 'T2' AS t2,
                                            'T3' AS t3, 'T4' AS t4))
 ORDER BY canal;

-- MODELO (resuelto) — los 10 clientes con más saldo y qué productos tienen
SELECT cl.id_cliente, cl.nombre, cl.segmento,
       ROUND(SUM(c.saldo)) AS saldo_total,
       COUNT(*)            AS cuentas,
       LISTAGG(DISTINCT p.nombre, ', ')
         WITHIN GROUP (ORDER BY p.nombre) AS productos
  FROM cliente cl
  JOIN cuenta  c ON c.id_cliente  = cl.id_cliente
  JOIN catalogo_producto p ON p.id_producto = c.id_producto
 WHERE c.estado = 'ACTIVA'
 GROUP BY cl.id_cliente, cl.nombre, cl.segmento
 ORDER BY saldo_total DESC
 FETCH FIRST 10 ROWS WITH TIES;

--
--  PREGUNTA 3.8 — ¿Qué diferencia hay entre FETCH FIRST 10 ROWS ONLY y
--  FETCH FIRST 10 ROWS WITH TIES? ¿En cuál de los dos casos puede
--  devolver más de 10 filas y por qué?

--  FETCH FIRST 10 ROWS ONLY corta exactamente en 10 filas, 
-- sin importar si la fila 10 y la 11 tienen el mismo valor de ORDER BY, 
-- puede dejar cortado a la mitad un empate, mostrando arbitrariamente solo una de dos filas empatadas.
-- FETCH FIRST 10 ROWS WITH TIES puede devolver más de 10 filas, si el valor de la fila 10 está
-- empatado con el de la 11,12,etc.
-- Incluye todas las que empatan con la última posición del corte así nunca deja a un cliente afuera
-- cuando tiene el mismo saldo que el que sí quedó adentro, esto es lo que ROWS ONLY nunca hace, siempre da
-- exactamente 10.

--  ESCRIBA 3.5 — Un informe de "clientes en fuga": clientes
--  PREFERENCIAL cuya última transferencia tiene más de 120 días,
--  mostrando cuántos días llevan inactivos, su saldo total y cuántos
--  productos tienen contratados.

WITH fecha_referencia AS (
  SELECT MAX(fecha_transf) AS hoy FROM transferencia
),
ultima_transf AS (
  SELECT c.id_cliente, MAX(t.fecha_transf) AS ultima_fecha
    FROM cuenta        c
    JOIN transferencia t ON t.cuenta_origen = c.id_cuenta
   GROUP BY c.id_cliente
)
SELECT cl.id_cliente, cl.nombre,
       ROUND(f.hoy - u.ultima_fecha)  AS dias_inactivo,
       ROUND(SUM(c.saldo))            AS saldo_total,
       COUNT(DISTINCT c.id_producto)  AS productos_contratados
  FROM cliente        cl
  JOIN ultima_transf  u ON u.id_cliente = cl.id_cliente
  JOIN cuenta         c ON c.id_cliente = cl.id_cliente
  CROSS JOIN fecha_referencia f
 WHERE cl.segmento = 'PREFERENCIAL'
   AND u.ultima_fecha < f.hoy - 120
   AND c.estado = 'ACTIVA'
 GROUP BY cl.id_cliente, cl.nombre, u.ultima_fecha, f.hoy
 ORDER BY dias_inactivo DESC;

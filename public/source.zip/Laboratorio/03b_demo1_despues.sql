-- ============================================================
-- 03b_demo1_despues.sql
-- DEMO 1 -- PARTE 2 de 2
-- Ejecutar DESPUES de 03_escalar_millones.sql (PEDIDO ya en
-- 2.120.000 filas, con estadisticas frescas garantizadas por
-- el GATHER_TABLE_STATS que trae 03 al final).
-- ============================================================

EXPLAIN PLAN FOR SELECT * FROM pedido WHERE id_ruta = 12;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(NULL,NULL,'BASIC +COST +ROWS +PREDICATE'));

-- Resultado esperado (capturado en el laboratorio real):
-- Rows: 57.297   Cost: 3.306   Operacion: TABLE ACCESS FULL

-- ------------------------------------------------------------
-- Lectura de los dos resultados (02b vs 03b):
-- La selectividad de id_ruta=12 es la misma en ambos casos (2,7%
-- de la tabla), pero el optimizador elige TABLE ACCESS FULL en los
-- dos. La causa no es el tamano de la tabla ni la selectividad 
-- es el factor de agrupamiento: las filas de esa ruta quedaron
-- dispersas por todos los bloques de la tabla (por como se
-- generaron los datos), asi que un indice obligaria a saltar entre
-- miles de bloques distintos, mas caro que leer todo de corrido.
--
-- Para confirmarlo de forma mas directa:
SELECT index_name, clustering_factor
FROM user_indexes
WHERE table_name = 'PEDIDO';
-- Un clustering_factor cercano al numero de FILAS de la tabla (en
-- vez de cercano al numero de BLOQUES) confirma que los datos de
-- esa columna estan dispersos, no agrupados.
-- ------------------------------------------------------------

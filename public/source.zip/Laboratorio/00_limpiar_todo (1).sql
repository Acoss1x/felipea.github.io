-- ============================================================
-- 00_limpiar_todo.sql
-- Corre esto UNA vez para dejar todo limpio antes de recrear el esquema.
-- Ignora los errores "table or view does not exist" que salgan aqui,
-- son normales si alguna tabla nunca se llego a crear.
-- ============================================================

DROP TABLE incidencia  CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido      CASCADE CONSTRAINTS PURGE;
DROP TABLE ruta        CASCADE CONSTRAINTS PURGE;
DROP TABLE cliente     CASCADE CONSTRAINTS PURGE;   -- esta es la que fallaba (auto-referencia)
DROP TABLE repartidor  CASCADE CONSTRAINTS PURGE;
DROP TABLE zona        CASCADE CONSTRAINTS PURGE;

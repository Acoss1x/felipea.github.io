-- ============================================================
-- 02_cargar_datos.sql
-- Ejecutar DESPUES de 01_crear_esquema.sql
-- ============================================================

-- ZONA (7 filas)
INSERT INTO zona VALUES ('BOG', 'Bogota Centro', 'Bogota');
INSERT INTO zona VALUES ('CHA', 'Chapinero', 'Bogota');
INSERT INTO zona VALUES ('USA', 'Usaquen', 'Bogota');
INSERT INTO zona VALUES ('MDE', 'El Poblado', 'Medellin');
INSERT INTO zona VALUES ('CTG', 'Bocagrande', 'Cartagena');
INSERT INTO zona VALUES ('CLO', 'San Fernando', 'Cali');
INSERT INTO zona VALUES ('BAQ', 'El Prado', 'Barranquilla');

-- REPARTIDOR (3 filas)
INSERT INTO repartidor VALUES (1, 'Carlos Mora', 'MOTO');
INSERT INTO repartidor VALUES (2, 'Luisa Pardo', 'BICICLETA');
INSERT INTO repartidor VALUES (3, 'Andres Vega', 'CARRO');

-- CLIENTE: dos pasadas porque se auto-referencia
-- Pasada 1: todos los clientes, sin referido todavia
INSERT INTO cliente (id_cliente, nombre, documento, id_cliente_referido)
SELECT rn, 'Cliente ' || rn, TO_CHAR(1000000 + rn), NULL
FROM (SELECT LEVEL rn FROM DUAL CONNECT BY LEVEL <= 40);

-- Pasada 2: ahora si, marcar quien referio a quien (3 clientes referidores)
UPDATE cliente SET id_cliente_referido = 6 WHERE id_cliente = 5;
UPDATE cliente SET id_cliente_referido = 9 WHERE id_cliente = 18;
UPDATE cliente SET id_cliente_referido = 4 WHERE id_cliente = 33;
COMMIT;

-- RUTA (37 filas, fechas repartidas entre enero y abril 2026)
INSERT INTO ruta (id_ruta, cod_zona_origen, cod_zona_destino, id_repartidor, fecha_salida)
SELECT
    rn,
    CASE MOD(rn,7) WHEN 0 THEN 'BOG' WHEN 1 THEN 'CHA' WHEN 2 THEN 'USA'
                   WHEN 3 THEN 'MDE' WHEN 4 THEN 'CTG' WHEN 5 THEN 'CLO' ELSE 'BAQ' END,
    CASE MOD(rn+3,7) WHEN 0 THEN 'BOG' WHEN 1 THEN 'CHA' WHEN 2 THEN 'USA'
                     WHEN 3 THEN 'MDE' WHEN 4 THEN 'CTG' WHEN 5 THEN 'CLO' ELSE 'BAQ' END,
    MOD(rn,3) + 1,
    DATE '2026-01-01' + TRUNC(rn * 3.2)
FROM (SELECT LEVEL rn FROM DUAL CONNECT BY LEVEL <= 37);
COMMIT;

-- PEDIDO base: 120.000 filas, por conjuntos (no loop)
INSERT INTO pedido (id_pedido, id_ruta, id_cliente, valor, estado, fecha_compra)
SELECT
    rn,
    MOD(rn, 37) + 1,
    MOD(rn, 40) + 1,
    ROUND(DBMS_RANDOM.VALUE(15000, 180000), -2),
    CASE MOD(rn, 20)
        WHEN 0 THEN 'CANCELADO' WHEN 1 THEN 'CANCELADO'
        WHEN 2 THEN 'CONFIRMADO' ELSE 'ENTREGADO'
    END,
    DATE '2026-01-01' + MOD(rn, 110) + DBMS_RANDOM.VALUE(0, 1)
FROM (SELECT LEVEL rn FROM DUAL CONNECT BY LEVEL <= 120000);
COMMIT;

-- INCIDENCIA (34 filas, algunas rutas quedan sin incidencia a proposito)
INSERT INTO incidencia (id_incidencia, id_ruta, tipo, fecha_incidencia)
SELECT
    rn,
    MOD(rn, 20) + 1,
    CASE MOD(rn,3) WHEN 0 THEN 'RETRASO' WHEN 1 THEN 'DANO' ELSE 'RECLAMO' END,
    DATE '2026-01-05' + MOD(rn, 100)
FROM (SELECT LEVEL rn FROM DUAL CONNECT BY LEVEL <= 34);
COMMIT;

-- Estadisticas iniciales
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'ZONA');
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'REPARTIDOR');
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'CLIENTE');
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'RUTA');
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'INCIDENCIA');

-- Verificacion
SELECT 'ZONA' t, COUNT(*) n FROM zona
UNION ALL SELECT 'REPARTIDOR', COUNT(*) FROM repartidor
UNION ALL SELECT 'CLIENTE', COUNT(*) FROM cliente
UNION ALL SELECT 'RUTA', COUNT(*) FROM ruta
UNION ALL SELECT 'PEDIDO', COUNT(*) FROM pedido
UNION ALL SELECT 'INCIDENCIA', COUNT(*) FROM incidencia;

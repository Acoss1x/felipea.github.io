-- ============================================================
-- 03_escalar_millones.sql
-- Ejecutar DESPUES de 02_cargar_datos.sql (PEDIDO en 120.000)
-- Escala PEDIDO a 2.120.000.
--
-- NOTA IMPORTANTE, observada en el laboratorio real:
-- la documentacion de Oracle dice que /*+ APPEND */ dispara
-- "online statistics gathering" solo si la tabla/particion de
-- destino esta VACIA antes de la carga. Como aqui PEDIDO ya
-- tenia 120.000 filas, esa condicion no se cumple y en la
-- practica, el comportamiento vario entre corridas (a veces las
-- estadisticas quedaron actualizadas solas, a veces no).
-- Para no depender de ese comportamiento incierto, este script
-- llama GATHER_TABLE_STATS explicitamente al final. Asi el punto
-- de partida para el DEMO 1 (y para el script 04) queda siempre
-- fresco y confiable, sin importar que hizo o no el APPEND por su cuenta.
-- ============================================================

INSERT /*+ APPEND */ INTO pedido (id_pedido, id_ruta, id_cliente, valor, estado, fecha_compra)
SELECT
    120000 + rn,
    MOD(rn, 37) + 1,
    MOD(rn, 40) + 1,
    ROUND(DBMS_RANDOM.VALUE(15000, 180000), -2),
    CASE MOD(rn, 20)
        WHEN 0 THEN 'CANCELADO' WHEN 1 THEN 'CANCELADO'
        WHEN 2 THEN 'CONFIRMADO' ELSE 'ENTREGADO'
    END,
    DATE '2026-01-01' + MOD(rn, 110) + DBMS_RANDOM.VALUE(0, 1)
FROM (SELECT LEVEL AS rn FROM DUAL CONNECT BY LEVEL <= 2000000);

COMMIT;

-- Actualiza estadisticas explicitamente
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);

-- Verificacion: ambas deben coincidir en 2.120.000
SELECT COUNT(*) AS filas_reales FROM pedido;
SELECT num_rows, last_analyzed FROM user_tables WHERE table_name = 'PEDIDO';

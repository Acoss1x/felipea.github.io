-- ============================================================
-- 02b_demo1_antes.sql
-- DEMO 1 -- PARTE 1 de 2
-- Ejecutar DESPUES de 02_cargar_datos.sql, y ANTES de
-- 03_escalar_millones.sql. En este punto PEDIDO tiene 120.000 filas.
-- ============================================================

EXPLAIN PLAN FOR SELECT * FROM pedido WHERE id_ruta = 12;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(NULL,NULL,'BASIC +COST +ROWS +PREDICATE'));

-- Resultado esperado (capturado en el laboratorio real):
-- Rows: 3.243   Cost: 205   Operacion: TABLE ACCESS FULL
-- Este resultado se compara contra 03b_demo1_despues.sql

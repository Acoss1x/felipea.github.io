-- ============================================================
-- ESQUEMA DE PRACTICA: RAPIDEX (mensajeria y domicilios)
-- 01_crear_esquema.sql
-- ============================================================

DROP TABLE incidencia  CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido      CASCADE CONSTRAINTS PURGE;
DROP TABLE ruta        CASCADE CONSTRAINTS PURGE;
DROP TABLE cliente     CASCADE CONSTRAINTS PURGE;
DROP TABLE repartidor  CASCADE CONSTRAINTS PURGE;
DROP TABLE zona        CASCADE CONSTRAINTS PURGE;

-- ZONA: analoga a AEROPUERTO
CREATE TABLE zona (
    cod_zona   VARCHAR2(5)  PRIMARY KEY,
    nombre     VARCHAR2(60) NOT NULL,
    ciudad     VARCHAR2(60) NOT NULL
);

-- REPARTIDOR: analoga a AERONAVE
CREATE TABLE repartidor (
    id_repartidor   NUMBER        PRIMARY KEY,
    nombre          VARCHAR2(80)  NOT NULL,
    vehiculo        VARCHAR2(30)  NOT NULL   -- 'MOTO', 'BICICLETA', 'CARRO'
);

-- CLIENTE: analoga a PASAJERO (con auto-referencia para "referidos")
CREATE TABLE cliente (
    id_cliente            NUMBER        PRIMARY KEY,
    nombre                VARCHAR2(80)  NOT NULL,
    documento             VARCHAR2(20)  NOT NULL,   -- VARCHAR2 a proposito, ojo con el tipo
    id_cliente_referido   NUMBER REFERENCES cliente(id_cliente)  -- NULL si no referio a nadie
);

-- RUTA: analoga a VUELO
CREATE TABLE ruta (
    id_ruta            NUMBER        PRIMARY KEY,
    cod_zona_origen    VARCHAR2(5)   REFERENCES zona(cod_zona),
    cod_zona_destino   VARCHAR2(5)   REFERENCES zona(cod_zona),
    id_repartidor      NUMBER        REFERENCES repartidor(id_repartidor),
    fecha_salida       DATE          NOT NULL
);

-- PEDIDO: analoga a RESERVA
CREATE TABLE pedido (
    id_pedido      NUMBER         PRIMARY KEY,
    id_ruta        NUMBER         REFERENCES ruta(id_ruta),
    id_cliente     NUMBER         REFERENCES cliente(id_cliente),
    valor          NUMBER(10,2)   NOT NULL,
    estado         VARCHAR2(12)   NOT NULL,   -- 'CONFIRMADO', 'ENTREGADO', 'CANCELADO'
    fecha_compra   DATE           NOT NULL
);

-- INCIDENCIA: analoga a INCIDENCIA (retrasos, danos, reclamos por ruta)
CREATE TABLE incidencia (
    id_incidencia      NUMBER        PRIMARY KEY,
    id_ruta            NUMBER        REFERENCES ruta(id_ruta),
    tipo               VARCHAR2(40)  NOT NULL,   -- 'RETRASO', 'DANO', 'RECLAMO'
    fecha_incidencia   DATE          NOT NULL
);

-- Indices (los mismos tipos que viste en clase)
CREATE INDEX idx_ruta_fecha   ON ruta(fecha_salida);
CREATE INDEX idx_pedido_ruta  ON pedido(id_ruta, estado);   -- compuesto, en ese orden a proposito

COMMIT;

-- ============================================================
-- 04_demo_estadisticas.sql
-- Ejecutar DESPUES de 03_escalar_millones.sql (PEDIDO en 2.120.000)
-- Demo de estadisticas desactualizadas: usa INSERT normal (SIN
-- /*+ APPEND */), que NO dispara actualizacion automatica de
-- estadisticas, asi si se logra el desfase real.
-- ============================================================

-- 1. Punto de partida
SELECT num_rows, last_analyzed FROM user_tables WHERE table_name = 'PEDIDO';

-- 2. Plan ANTES de insertar mas filas
EXPLAIN PLAN FOR SELECT * FROM pedido WHERE id_ruta = 12;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(NULL,NULL,'BASIC +COST +ROWS +PREDICATE'));

-- 3. Insertar 300.000 filas mas, con INSERT NORMAL (sin APPEND)
INSERT INTO pedido (id_pedido, id_ruta, id_cliente, valor, estado, fecha_compra)
SELECT
    2120000 + rn,
    MOD(rn, 37) + 1,
    MOD(rn, 40) + 1,
    ROUND(DBMS_RANDOM.VALUE(15000, 180000), -2),
    CASE MOD(rn, 20)
        WHEN 0 THEN 'CANCELADO' WHEN 1 THEN 'CANCELADO'
        WHEN 2 THEN 'CONFIRMADO' ELSE 'ENTREGADO'
    END,
    DATE '2026-01-01' + MOD(rn, 110) + DBMS_RANDOM.VALUE(0, 1)
FROM (SELECT LEVEL AS rn FROM DUAL CONNECT BY LEVEL <= 300000);
COMMIT;

-- 4. Confirma el conteo REAL (deberia dar 2.420.000)
SELECT COUNT(*) AS filas_reales FROM pedido;

-- 5. Confirma que las estadisticas SIGUEN diciendo el numero viejo
--    (sin APPEND, no hay actualizacion automatica)
SELECT num_rows, last_analyzed FROM user_tables WHERE table_name = 'PEDIDO';

-- 6. Plan CON estadisticas desactualizadas (el antes del demo)
--    Anota el Rows y Cost: deberian seguir pareciendose al paso 2,
--    NO reflejar las 300.000 filas nuevas.
EXPLAIN PLAN FOR SELECT * FROM pedido WHERE id_ruta = 12;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(NULL,NULL,'BASIC +COST +ROWS +PREDICATE'));

-- 7. Actualizar estadisticas manualmente
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO', cascade => TRUE);

-- 8. Confirma que ahora si reflejan la realidad
SELECT num_rows, last_analyzed FROM user_tables WHERE table_name = 'PEDIDO';

-- 9. Plan DESPUES de actualizar (el despues del demo)
--    Rows y Cost deberian subir, reflejando las 2.420.000 filas reales.
EXPLAIN PLAN FOR SELECT * FROM pedido WHERE id_ruta = 12;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(NULL,NULL,'BASIC +COST +ROWS +PREDICATE'));
